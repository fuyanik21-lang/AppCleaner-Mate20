# App Cleaner — Huawei Mate 20

Kişisel kullanım için hazırlanmış Android uygulaması. Ana hedef Huawei Mate 20 (HMA-L09/HMA-L29), özellikle EMUI 12 altında Android 10/API 29 tabanında çalışan cihazlardır.

## Özellikler

- Kurulu kullanıcı/sistem uygulamalarını listeler.
- Shizuku UserService üzerinden `am force-stop` kullanarak seçili üçüncü taraf uygulamaları durdurur.
- Shizuku çalışmıyorsa UsageStats üzerinden yakın zamanda kullanılan uygulamaları gösterir ve gerçek process listesi olduğunu iddia etmez.
- Beyaz liste, toplu durdurma, son 100 işlem geçmişi ve WorkManager tabanlı otomatik temizleme sunar.
- App Cleaner, Shizuku, Android System, System UI, varsayılan launcher/IME/dialer ve çeşitli kritik servisleri korur.
- INTERNET, reklam, analytics veya telemetry yoktur.

## Huawei Mate 20 ve Android 10

EMUI sürümü Android API seviyesi değildir. Uygulama runtime'da `Build.VERSION.SDK_INT` kullanır. Proje `minSdk 28`, `compileSdk 36`, `targetSdk 36` olarak yapılandırılmıştır.

Android 10 ve altındaki rootsuz cihazlarda Android 11'in Wireless Debugging eşleştirmesi yoktur. Shizuku'yu bilgisayar ADB ile başlatın:

1. Shizuku'yu resmi kaynaktan yükleyin: https://shizuku.rikka.app/download/
2. Ayarlar > Telefon hakkında üzerinden Geliştirici seçeneklerini açın.
3. USB hata ayıklamayı açın.
4. EMUI'de mevcutsa **Allow ADB debugging in 'Charge only' mode** seçeneğini açın.
5. Telefonu USB ile bilgisayara bağlayın ve RSA onayını verin.
6. Android Platform Tools terminalinde:

```bash
adb devices
```

Cihazın yanında `device` görülmelidir.

7. Shizuku uygulamasındaki **Start via connecting to a computer** bölümünde gösterilen güncel komutu çalıştırın. Yaygın örnek:

```bash
adb shell sh /sdcard/Android/data/moe.shizuku.privileged.api/start.sh
```

Shizuku uygulamasının gösterdiği komut farklıysa onu kullanın.

Telefon yeniden başlatıldığında rootsuz Android 10 cihazlarda Shizuku'yu ADB ile yeniden başlatmanız gerekebilir. Shizuku başladıktan sonra USB kablosunu çıkarabilirsiniz.

## Usage Access

Shizuku yokken fallback listeleme ve son kullanılan uygulamaları koruma için uygulama içindeki **Kullanım erişimi ayarları** düğmesinden App Cleaner'a Usage Access verin.

## EMUI App Launch

EMUI arka plan görevlerini geciktirebilir veya durdurabilir. Daha iyi WorkManager davranışı için cihazınızda menü adları uygun olduğu ölçüde:

Ayarlar → Pil → Uygulama başlatma → App Cleaner → Otomatik yönetimi kapat

ve varsa Otomatik başlatma / İkincil başlatma / Arka planda çalıştırma seçeneklerini etkinleştirin. Zamanlanmış temizliğin kesin dakika garantisi yoktur.

## Derleme

Gereksinimler:

- Android Studio güncel stabil sürüm
- JDK 17 veya uyumlu daha yeni JDK
- Android SDK Platform 36

Linux/macOS:

```bash
./gradlew assembleDebug
```

Windows:

```bat
gradlew.bat assembleDebug
```

APK:

`app/build/outputs/apk/debug/app-debug.apk`

ADB ile yükleme:

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

## Güvenlik / sınırlamalar

- Uygulama manuel shell terminali sunmaz; paket adları doğrulanır ve `ProcessBuilder` argümanlarıyla ayrı parametreler halinde geçirilir.
- Force-stop yalnızca Shizuku/Sui/root yetkisi mevcutken etkinleşir.
- ADB shell yetkileri Android/EMUI sürümüne göre değişebilir; bazı OEM işlemleri reddedebilir.
- `QUERY_ALL_PACKAGES`, kişisel sideload kullanımında tüm uygulamaları göstermek için kullanılır.
- Uygulama `INTERNET` ve `REQUEST_INSTALL_PACKAGES` izinlerini istemez.
