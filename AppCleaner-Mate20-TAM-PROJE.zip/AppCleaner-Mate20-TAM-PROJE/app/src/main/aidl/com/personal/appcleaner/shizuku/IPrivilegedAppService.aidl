package com.personal.appcleaner.shizuku;

interface IPrivilegedAppService {
    int forceStop(String packageName);
    String listProcesses();
    int privilegeUid();
}
