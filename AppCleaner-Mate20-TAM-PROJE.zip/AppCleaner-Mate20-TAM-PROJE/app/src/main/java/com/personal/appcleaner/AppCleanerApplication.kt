package com.personal.appcleaner

import android.app.Application
import com.personal.appcleaner.data.DependencyManager
import com.personal.appcleaner.data.DependencyNavigator
import com.personal.appcleaner.repository.AppRepository
import com.personal.appcleaner.repository.HistoryRepository
import com.personal.appcleaner.repository.InstalledAppsRepository
import com.personal.appcleaner.repository.SettingsRepository
import com.personal.appcleaner.repository.UsageStatsRepository
import com.personal.appcleaner.service.AppStopManager
import com.personal.appcleaner.shizuku.ShizukuManager
import com.personal.appcleaner.util.CriticalAppDetector
import com.personal.appcleaner.util.HuaweiDeviceHelper

class AppCleanerApplication : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}

class AppContainer(app: Application) {
    val settingsRepository = SettingsRepository(app)
    val historyRepository = HistoryRepository(app)
    val installedAppsRepository = InstalledAppsRepository(app)
    val usageStatsRepository = UsageStatsRepository(app)
    val criticalAppDetector = CriticalAppDetector(app)
    val huaweiDeviceHelper = HuaweiDeviceHelper(app)
    val shizukuManager = ShizukuManager(app)
    val dependencyManager = DependencyManager(shizukuManager)
    val dependencyNavigator = DependencyNavigator(app, huaweiDeviceHelper)
    val appRepository = AppRepository(installedAppsRepository, usageStatsRepository, settingsRepository, criticalAppDetector, shizukuManager)
    val appStopManager = AppStopManager(installedAppsRepository, settingsRepository, historyRepository, criticalAppDetector, shizukuManager)
}
