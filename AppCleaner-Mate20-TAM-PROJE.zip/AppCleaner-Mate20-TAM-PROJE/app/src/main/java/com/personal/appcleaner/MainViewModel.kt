package com.personal.appcleaner

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.personal.appcleaner.model.AppFilter
import com.personal.appcleaner.model.AppInfo
import com.personal.appcleaner.model.AppPresence
import com.personal.appcleaner.model.AppUiState
import com.personal.appcleaner.model.AutoCleanInterval
import com.personal.appcleaner.model.BatchSummary
import com.personal.appcleaner.model.CleanerSettings
import com.personal.appcleaner.model.StopHistory
import com.personal.appcleaner.model.toTurkishMessage
import com.personal.appcleaner.worker.AutoCleanScheduler
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val c = (application as AppCleanerApplication).container
    private val _ui = MutableStateFlow(AppUiState())
    val ui: StateFlow<AppUiState> = _ui.asStateFlow()
    val settings: StateFlow<CleanerSettings> = c.settingsRepository.settings.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), CleanerSettings())
    val history: StateFlow<List<StopHistory>> = c.historyRepository.history.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    init {
        viewModelScope.launch {
            c.shizukuManager.state.collect { state ->
                _ui.value = _ui.value.copy(shizuku = state)
            }
        }
        refresh()
    }

    fun onResume() {
        c.shizukuManager.refresh()
        refresh()
    }

    fun refresh() {
        if (_ui.value.loading) return
        viewModelScope.launch {
            _ui.value = _ui.value.copy(loading = true, usageAccess = c.usageStatsRepository.hasUsageAccess())
            val selected = _ui.value.apps.filter { it.selected }.map { it.packageName }.toSet()
            val apps = runCatching { c.appRepository.loadApps() }.getOrElse {
                _ui.value = _ui.value.copy(message = "Uygulama listesi okunamadı: ${it.message.orEmpty()}")
                emptyList()
            }.map { it.copy(selected = it.packageName in selected) }
            _ui.value = _ui.value.copy(apps = apps, loading = false, usageAccess = c.usageStatsRepository.hasUsageAccess())
            syncSelected()
        }
    }

    fun setQuery(value: String) { _ui.value = _ui.value.copy(query = value) }
    fun setFilter(value: AppFilter) { _ui.value = _ui.value.copy(filter = value) }
    fun clearMessage() { _ui.value = _ui.value.copy(message = null) }

    fun visibleApps(state: AppUiState = _ui.value): List<AppInfo> = state.apps.filter { app ->
        val queryMatch = state.query.isBlank() || app.label.contains(state.query, true) || app.packageName.contains(state.query, true)
        val filterMatch = when (state.filter) {
            AppFilter.RUNNING -> app.presence != AppPresence.UNKNOWN && !app.isSystem
            AppFilter.USER -> !app.isSystem && !app.isWhitelisted
            AppFilter.SYSTEM -> app.isSystem
            AppFilter.EXCLUDED -> app.isWhitelisted
        }
        queryMatch && filterMatch
    }

    fun toggleSelected(packageName: String) {
        _ui.value = _ui.value.copy(apps = _ui.value.apps.map { if (it.packageName == packageName && !it.isProtected) it.copy(selected = !it.selected) else it })
        syncSelected()
    }

    fun selectAllVisible() {
        val visible = visibleApps().filter { !it.isProtected && !it.isWhitelisted }.map { it.packageName }.toSet()
        _ui.value = _ui.value.copy(apps = _ui.value.apps.map { if (it.packageName in visible) it.copy(selected = true) else it })
        syncSelected()
    }

    fun clearSelection() {
        _ui.value = _ui.value.copy(apps = _ui.value.apps.map { it.copy(selected = false) })
        syncSelected()
    }

    fun requestBatchConfirmation() {
        if (_ui.value.selectedCount > 0) _ui.value = _ui.value.copy(confirmBatch = true)
    }

    fun cancelBatch() { _ui.value = _ui.value.copy(confirmBatch = false) }

    fun stopSelected() {
        _ui.value = _ui.value.copy(confirmBatch = false)
        viewModelScope.launch {
            val results = c.appStopManager.stopAllSelectedApps()
            val summary = BatchSummary.from(results)
            _ui.value = _ui.value.copy(message = "${summary.total} uygulamadan ${summary.successful} tanesi durduruldu.")
            clearSelection()
            refresh()
        }
    }

    fun stopOne(packageName: String) {
        viewModelScope.launch {
            val result = c.appStopManager.stopApp(packageName)
            _ui.value = _ui.value.copy(message = result.toTurkishMessage())
            refresh()
        }
    }

    fun setWhitelisted(packageName: String, enabled: Boolean) {
        viewModelScope.launch { c.settingsRepository.setWhitelisted(packageName, enabled); refresh() }
    }

    fun setAutoCleanPackage(packageName: String, enabled: Boolean) {
        viewModelScope.launch { c.settingsRepository.setAutoCleanPackage(packageName, enabled); refresh() }
    }

    fun setAutoInterval(interval: AutoCleanInterval) {
        viewModelScope.launch {
            c.settingsRepository.setAutoCleanInterval(interval)
            AutoCleanScheduler.apply(getApplication(), interval)
        }
    }

    fun setRecentProtection(minutes: Int) { viewModelScope.launch { c.settingsRepository.setProtectRecentMinutes(minutes) } }
    fun clearHistory() { viewModelScope.launch { c.historyRepository.clear() } }
    fun requestShizukuPermission() = c.shizukuManager.requestPermission()
    fun openShizukuInstall() = c.dependencyNavigator.openShizukuInstallPage()
    fun openShizuku() = c.dependencyNavigator.openShizukuApp()
    fun openDeveloperOptions() = c.dependencyNavigator.openDeveloperOptions()
    fun openUsageAccess() = c.dependencyNavigator.openUsageAccessSettings()
    fun openHuaweiSettings() = c.dependencyNavigator.openHuaweiBackgroundSettings()

    private fun syncSelected() {
        c.appStopManager.updateSelectedPackages(_ui.value.apps.filter { it.selected }.map { it.packageName }.toSet())
    }
}
