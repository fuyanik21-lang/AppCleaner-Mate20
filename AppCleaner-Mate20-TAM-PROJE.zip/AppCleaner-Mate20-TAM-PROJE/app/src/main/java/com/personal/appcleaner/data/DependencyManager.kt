package com.personal.appcleaner.data

import android.os.Build
import com.personal.appcleaner.model.ShizukuSetupMode
import com.personal.appcleaner.shizuku.ShizukuManager

class DependencyManager(private val shizuku: ShizukuManager) {
    fun currentMode(): ShizukuSetupMode {
        val uid = shizuku.state.value.privilegeUid
        return resolveMode(Build.VERSION.SDK_INT, uid == 0, shizuku.state.value.installed)
    }

    companion object {
        fun resolveMode(api: Int, rootAvailable: Boolean, shizukuInstalled: Boolean = true): ShizukuSetupMode = when {
            rootAvailable -> ShizukuSetupMode.ROOT
            !shizukuInstalled -> ShizukuSetupMode.UNAVAILABLE
            api >= 30 -> ShizukuSetupMode.WIRELESS_DEBUGGING
            else -> ShizukuSetupMode.COMPUTER_ADB
        }
    }
}
