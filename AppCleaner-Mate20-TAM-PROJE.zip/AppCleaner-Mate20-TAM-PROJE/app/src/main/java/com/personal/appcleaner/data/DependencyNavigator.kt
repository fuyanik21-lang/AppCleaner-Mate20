package com.personal.appcleaner.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import com.personal.appcleaner.shizuku.ShizukuManager
import com.personal.appcleaner.util.HuaweiDeviceHelper

class DependencyNavigator(
    private val context: Context,
    private val huawei: HuaweiDeviceHelper
) {
    fun openShizukuInstallPage() {
        val market = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=${ShizukuManager.SHIZUKU_PACKAGE}"))
        if (!start(market)) start(Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/")))
    }

    fun openShizukuApp() {
        val intent = context.packageManager.getLaunchIntentForPackage(ShizukuManager.SHIZUKU_PACKAGE)
        if (intent != null) start(intent)
    }

    fun openDeveloperOptions() { start(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)) }
    fun openUsageAccessSettings() { start(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
    fun openHuaweiBackgroundSettings() = huawei.openBackgroundSettings()

    private fun start(intent: Intent): Boolean = try {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        true
    } catch (_: Throwable) { false }
}
