package com.personal.appcleaner.model

enum class AppPresence { RUNNING, RECENT, UNKNOWN }

data class AppInfo(
    val packageName: String,
    val label: String,
    val isSystem: Boolean,
    val presence: AppPresence,
    val lastUsed: Long = 0L,
    val isProtected: Boolean = false,
    val isWhitelisted: Boolean = false,
    val isAutoClean: Boolean = false,
    val selected: Boolean = false
)
