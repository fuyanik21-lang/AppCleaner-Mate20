package com.personal.appcleaner.model

data class AppUiState(
    val apps: List<AppInfo> = emptyList(),
    val query: String = "",
    val filter: AppFilter = AppFilter.USER,
    val loading: Boolean = false,
    val shizuku: ShizukuState = ShizukuState(),
    val usageAccess: Boolean = false,
    val message: String? = null,
    val confirmBatch: Boolean = false
) {
    val selectedCount: Int get() = apps.count { it.selected }
}
