package com.personal.appcleaner.model

enum class AutoCleanInterval(val minutes: Long, val title: String) {
    OFF(0, "Kapalı"),
    MIN_30(30, "30 dakika"),
    HOUR_1(60, "1 saat"),
    HOUR_2(120, "2 saat"),
    HOUR_4(240, "4 saat")
}

enum class AppFilter(val title: String) {
    RUNNING("Çalışanlar"),
    USER("Kullanıcı"),
    SYSTEM("Sistem"),
    EXCLUDED("Hariç")
}

data class CleanerSettings(
    val whitelist: Set<String> = emptySet(),
    val autoCleanPackages: Set<String> = emptySet(),
    val autoCleanInterval: AutoCleanInterval = AutoCleanInterval.OFF,
    val protectRecentMinutes: Int = 15
)

data class BatchSummary(val total: Int, val successful: Int) {
    val failed: Int get() = total - successful
    companion object {
        fun from(results: List<StopResult>) = BatchSummary(results.size, results.count { it.isSuccessful() })
    }
}
