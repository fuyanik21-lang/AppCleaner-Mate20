package com.personal.appcleaner.model

enum class ShizukuSetupMode { ROOT, WIRELESS_DEBUGGING, COMPUTER_ADB, UNAVAILABLE }

data class ShizukuState(
    val installed: Boolean = false,
    val binderAlive: Boolean = false,
    val permissionGranted: Boolean = false,
    val userServiceConnected: Boolean = false,
    val privilegeUid: Int? = null,
    val mode: ShizukuSetupMode = ShizukuSetupMode.UNAVAILABLE,
    val error: String? = null
) {
    val ready: Boolean get() = installed && binderAlive && permissionGranted && userServiceConnected
}
