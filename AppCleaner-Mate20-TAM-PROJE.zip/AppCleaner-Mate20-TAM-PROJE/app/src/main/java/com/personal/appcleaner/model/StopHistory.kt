package com.personal.appcleaner.model

enum class StopOrigin { MANUAL, AUTOMATIC }

data class StopHistory(
    val timestamp: Long,
    val appLabel: String,
    val packageName: String,
    val success: Boolean,
    val reason: String,
    val origin: StopOrigin,
    val privilegeMode: String
)
