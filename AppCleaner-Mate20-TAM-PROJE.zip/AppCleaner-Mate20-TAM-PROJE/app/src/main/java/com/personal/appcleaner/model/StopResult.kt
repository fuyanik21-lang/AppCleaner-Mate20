package com.personal.appcleaner.model

sealed interface StopResult {
    val packageName: String

    data class Success(override val packageName: String) : StopResult
    data class ShizukuNotInstalled(override val packageName: String) : StopResult
    data class ShizukuNotRunning(override val packageName: String) : StopResult
    data class PermissionDenied(override val packageName: String) : StopResult
    data class PackageNotFound(override val packageName: String) : StopResult
    data class ProtectedPackage(override val packageName: String) : StopResult
    data class AlreadyStopped(override val packageName: String) : StopResult
    data class ShellPermissionDenied(override val packageName: String) : StopResult
    data class BinderDisconnected(override val packageName: String) : StopResult
    data class OemRestriction(override val packageName: String, val detail: String = "") : StopResult
    data class CommandFailed(override val packageName: String, val code: Int, val detail: String = "") : StopResult
    data class UnknownError(override val packageName: String, val detail: String = "") : StopResult
}

fun StopResult.isSuccessful(): Boolean = this is StopResult.Success || this is StopResult.AlreadyStopped

fun StopResult.toTurkishMessage(): String = when (this) {
    is StopResult.Success -> "Uygulama durduruldu."
    is StopResult.ShizukuNotInstalled -> "Shizuku yüklü değil."
    is StopResult.ShizukuNotRunning -> "Shizuku çalışmıyor."
    is StopResult.PermissionDenied -> "Shizuku izni verilmedi."
    is StopResult.PackageNotFound -> "Uygulama artık kurulu değil."
    is StopResult.ProtectedPackage -> "Bu uygulama güvenlik nedeniyle korunuyor."
    is StopResult.AlreadyStopped -> "Uygulama zaten çalışmıyor."
    is StopResult.ShellPermissionDenied -> "Shell yetkisi işlemi reddetti."
    is StopResult.BinderDisconnected -> "Shizuku bağlantısı kesildi."
    is StopResult.OemRestriction -> "EMUI/OEM kısıtlaması nedeniyle işlem tamamlanamadı${detail.takeIf { it.isNotBlank() }?.let { ": $it" } ?: ""}."
    is StopResult.CommandFailed -> "Durdurma komutu başarısız oldu (kod $code)${detail.takeIf { it.isNotBlank() }?.let { ": $it" } ?: ""}."
    is StopResult.UnknownError -> "Beklenmeyen hata${detail.takeIf { it.isNotBlank() }?.let { ": $it" } ?: ""}."
}
