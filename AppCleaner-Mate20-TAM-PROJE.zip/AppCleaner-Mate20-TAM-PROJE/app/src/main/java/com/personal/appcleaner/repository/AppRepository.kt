package com.personal.appcleaner.repository

import com.personal.appcleaner.model.AppInfo
import com.personal.appcleaner.model.AppPresence
import com.personal.appcleaner.shizuku.ShizukuManager
import com.personal.appcleaner.util.CriticalAppDetector
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

class AppRepository(
    private val installedApps: InstalledAppsRepository,
    private val usage: UsageStatsRepository,
    private val settings: SettingsRepository,
    private val critical: CriticalAppDetector,
    private val shizuku: ShizukuManager
) {
    suspend fun loadApps(): List<AppInfo> = withContext(Dispatchers.IO) {
        val installed = installedApps.getInstalledApps()
        val installedNames = installed.map { it.packageName }.toSet()
        val cfg = settings.settings.first()
        val protected = critical.protectedPackages()
        val shizukuService = if (shizuku.state.value.binderAlive && shizuku.state.value.permissionGranted) shizuku.ensureService() else null
        val processNames = if (shizukuService != null) parseProcesses(runCatching { shizukuService.listProcesses() }.getOrDefault(""), installedNames) else emptySet()
        val recent = if (shizukuService == null) usage.recentPackages() else emptyMap()

        installed.map { app ->
            val presence = when {
                app.packageName in processNames -> AppPresence.RUNNING
                recent.containsKey(app.packageName) -> AppPresence.RECENT
                else -> AppPresence.UNKNOWN
            }
            AppInfo(
                packageName = app.packageName,
                label = app.label,
                isSystem = app.isSystem,
                presence = presence,
                lastUsed = recent[app.packageName] ?: 0L,
                isProtected = app.packageName in protected,
                isWhitelisted = app.packageName in cfg.whitelist,
                isAutoClean = app.packageName in cfg.autoCleanPackages
            )
        }
    }

    private fun parseProcesses(output: String, installed: Set<String>): Set<String> = buildSet {
        output.lineSequence().forEach { line ->
            val token = line.trim().split(Regex("\\s+")).lastOrNull().orEmpty()
            val base = token.substringBefore(':')
            if (base in installed) add(base)
        }
    }
}
