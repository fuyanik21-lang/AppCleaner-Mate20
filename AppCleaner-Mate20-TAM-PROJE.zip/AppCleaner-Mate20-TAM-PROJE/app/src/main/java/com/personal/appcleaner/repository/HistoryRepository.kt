package com.personal.appcleaner.repository

import android.content.Context
import android.util.Base64
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.personal.appcleaner.model.StopHistory
import com.personal.appcleaner.model.StopOrigin
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.historyDataStore by preferencesDataStore("app_cleaner_history")

class HistoryRepository(private val context: Context) {
    private val historyKey = stringPreferencesKey("history_records")

    val history: Flow<List<StopHistory>> = context.historyDataStore.data.map { p ->
        decodeAll(p[historyKey].orEmpty())
    }

    suspend fun add(entry: StopHistory) {
        context.historyDataStore.edit { p ->
            val current = decodeAll(p[historyKey].orEmpty()).toMutableList()
            current.add(0, entry)
            while (current.size > 100) current.removeLast()
            p[historyKey] = current.joinToString("\n") { encode(it) }
        }
    }

    suspend fun clear() {
        context.historyDataStore.edit { it.remove(historyKey) }
    }

    private fun encode(value: StopHistory): String = listOf(
        value.timestamp.toString(),
        b64(value.appLabel), b64(value.packageName), value.success.toString(),
        b64(value.reason), value.origin.name, b64(value.privilegeMode)
    ).joinToString("|")

    private fun decodeAll(raw: String): List<StopHistory> = raw.lineSequence().mapNotNull { line ->
        val p = line.split('|')
        if (p.size != 7) return@mapNotNull null
        runCatching {
            StopHistory(
                timestamp = p[0].toLong(),
                appLabel = unb64(p[1]),
                packageName = unb64(p[2]),
                success = p[3].toBooleanStrictOrNull() ?: false,
                reason = unb64(p[4]),
                origin = StopOrigin.valueOf(p[5]),
                privilegeMode = unb64(p[6])
            )
        }.getOrNull()
    }.toList()

    private fun b64(s: String): String = Base64.encodeToString(s.toByteArray(Charsets.UTF_8), Base64.NO_WRAP or Base64.URL_SAFE)
    private fun unb64(s: String): String = String(Base64.decode(s, Base64.NO_WRAP or Base64.URL_SAFE), Charsets.UTF_8)
}
