package com.personal.appcleaner.repository

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class InstalledAppsRepository(private val context: Context) {
    private val pm: PackageManager get() = context.packageManager

    data class InstalledApp(val packageName: String, val label: String, val isSystem: Boolean)

    suspend fun getInstalledApps(): List<InstalledApp> = withContext(Dispatchers.IO) {
        val apps = if (Build.VERSION.SDK_INT >= 33) {
            pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION") pm.getInstalledApplications(0)
        }
        apps.mapNotNull { info ->
            runCatching {
                InstalledApp(
                    packageName = info.packageName,
                    label = pm.getApplicationLabel(info).toString().ifBlank { info.packageName },
                    isSystem = (info.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                )
            }.getOrNull()
        }.sortedBy { it.label.lowercase() }
    }

    fun isInstalled(packageName: String): Boolean = try {
        if (Build.VERSION.SDK_INT >= 33) pm.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(0))
        else @Suppress("DEPRECATION") pm.getPackageInfo(packageName, 0)
        true
    } catch (_: PackageManager.NameNotFoundException) {
        false
    } catch (_: Throwable) {
        false
    }

    fun labelFor(packageName: String): String = runCatching {
        val info = if (Build.VERSION.SDK_INT >= 33) pm.getApplicationInfo(packageName, PackageManager.ApplicationInfoFlags.of(0))
        else @Suppress("DEPRECATION") pm.getApplicationInfo(packageName, 0)
        pm.getApplicationLabel(info).toString()
    }.getOrDefault(packageName)
}
