package com.personal.appcleaner.repository

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.personal.appcleaner.model.AutoCleanInterval
import com.personal.appcleaner.model.CleanerSettings
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.settingsDataStore by preferencesDataStore("app_cleaner_settings")

class SettingsRepository(private val context: Context) {
    private object Keys {
        val WHITELIST = stringSetPreferencesKey("whitelist")
        val AUTO_PACKAGES = stringSetPreferencesKey("auto_packages")
        val AUTO_INTERVAL = stringPreferencesKey("auto_interval")
        val RECENT_MINUTES = intPreferencesKey("recent_minutes")
        val ONBOARDING_DONE = booleanPreferencesKey("onboarding_done")
    }

    val settings: Flow<CleanerSettings> = context.settingsDataStore.data.map { p ->
        CleanerSettings(
            whitelist = p[Keys.WHITELIST] ?: emptySet(),
            autoCleanPackages = p[Keys.AUTO_PACKAGES] ?: emptySet(),
            autoCleanInterval = runCatching { AutoCleanInterval.valueOf(p[Keys.AUTO_INTERVAL] ?: AutoCleanInterval.OFF.name) }.getOrDefault(AutoCleanInterval.OFF),
            protectRecentMinutes = p[Keys.RECENT_MINUTES] ?: 15
        )
    }

    suspend fun setWhitelisted(packageName: String, enabled: Boolean) {
        context.settingsDataStore.edit { p ->
            val set = (p[Keys.WHITELIST] ?: emptySet()).toMutableSet()
            if (enabled) set.add(packageName) else set.remove(packageName)
            p[Keys.WHITELIST] = set
        }
    }

    suspend fun setAutoCleanPackage(packageName: String, enabled: Boolean) {
        context.settingsDataStore.edit { p ->
            val set = (p[Keys.AUTO_PACKAGES] ?: emptySet()).toMutableSet()
            if (enabled) set.add(packageName) else set.remove(packageName)
            p[Keys.AUTO_PACKAGES] = set
        }
    }

    suspend fun setAutoCleanInterval(interval: AutoCleanInterval) {
        context.settingsDataStore.edit { it[Keys.AUTO_INTERVAL] = interval.name }
    }

    suspend fun setProtectRecentMinutes(minutes: Int) {
        context.settingsDataStore.edit { it[Keys.RECENT_MINUTES] = minutes.coerceAtLeast(0) }
    }

    suspend fun setOnboardingDone(done: Boolean) {
        context.settingsDataStore.edit { it[Keys.ONBOARDING_DONE] = done }
    }
}
