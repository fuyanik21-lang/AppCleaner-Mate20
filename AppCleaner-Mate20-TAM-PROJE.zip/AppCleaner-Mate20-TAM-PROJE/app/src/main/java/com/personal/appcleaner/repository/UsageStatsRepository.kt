package com.personal.appcleaner.repository

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Build
import android.os.Process
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class UsageStatsRepository(private val context: Context) {
    private val manager = context.getSystemService(UsageStatsManager::class.java)

    fun hasUsageAccess(): Boolean {
        val appOps = context.getSystemService(AppOpsManager::class.java)
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            appOps.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName)
        } else {
            @Suppress("DEPRECATION") appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.packageName)
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    suspend fun recentPackages(windowMs: Long = 6 * 60 * 60 * 1000L): Map<String, Long> = withContext(Dispatchers.IO) {
        if (!hasUsageAccess()) return@withContext emptyMap()
        val now = System.currentTimeMillis()
        manager.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, now - windowMs, now)
            .filter { it.lastTimeUsed >= now - windowMs }
            .associate { it.packageName to it.lastTimeUsed }
    }

    suspend fun foregroundPackage(): String? = withContext(Dispatchers.IO) {
        if (!hasUsageAccess()) return@withContext null
        val now = System.currentTimeMillis()
        val events = manager.queryEvents(now - 2 * 60 * 1000L, now)
        val event = UsageEvents.Event()
        var foreground: String? = null
        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            val resumed = if (Build.VERSION.SDK_INT >= 29) event.eventType == UsageEvents.Event.ACTIVITY_RESUMED
            else @Suppress("DEPRECATION") event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND
            if (resumed) foreground = event.packageName
        }
        foreground
    }

    suspend fun lastUsed(packageName: String, lookbackMs: Long = 24 * 60 * 60 * 1000L): Long = withContext(Dispatchers.IO) {
        if (!hasUsageAccess()) return@withContext 0L
        val now = System.currentTimeMillis()
        manager.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, now - lookbackMs, now)
            .filter { it.packageName == packageName }
            .maxOfOrNull { it.lastTimeUsed } ?: 0L
    }
}

object RecentUsagePolicy {
    fun shouldProtect(lastUsed: Long, now: Long, minutes: Int): Boolean {
        if (minutes <= 0 || lastUsed <= 0L) return false
        return now - lastUsed <= minutes * 60_000L
    }
}
