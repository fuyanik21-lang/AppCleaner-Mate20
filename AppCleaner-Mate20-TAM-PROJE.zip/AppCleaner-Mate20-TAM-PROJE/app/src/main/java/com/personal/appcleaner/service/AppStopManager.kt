package com.personal.appcleaner.service

import com.personal.appcleaner.model.StopHistory
import com.personal.appcleaner.model.StopOrigin
import com.personal.appcleaner.model.StopResult
import com.personal.appcleaner.model.isSuccessful
import com.personal.appcleaner.model.toTurkishMessage
import com.personal.appcleaner.repository.HistoryRepository
import com.personal.appcleaner.repository.InstalledAppsRepository
import com.personal.appcleaner.repository.SettingsRepository
import com.personal.appcleaner.shizuku.ShizukuManager
import com.personal.appcleaner.util.CriticalAppDetector
import com.personal.appcleaner.util.PackageNameValidator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

class AppStopManager(
    private val installedApps: InstalledAppsRepository,
    private val settings: SettingsRepository,
    private val history: HistoryRepository,
    private val critical: CriticalAppDetector,
    private val shizuku: ShizukuManager
) {
    @Volatile private var selectedPackages: Set<String> = emptySet()

    fun updateSelectedPackages(packages: Set<String>) { selectedPackages = packages }

    suspend fun stopApp(packageName: String): StopResult = stopAppInternal(packageName, StopOrigin.MANUAL)
    suspend fun stopAppAutomatic(packageName: String): StopResult = stopAppInternal(packageName, StopOrigin.AUTOMATIC)

    suspend fun stopApps(packageNames: List<String>): List<StopResult> = packageNames.distinct().map { stopApp(it) }
    suspend fun stopAllSelectedApps(): List<StopResult> = stopApps(selectedPackages.toList())

    fun isShizukuAvailable(): Boolean = shizuku.state.value.binderAlive
    fun hasShizukuPermission(): Boolean = shizuku.state.value.permissionGranted

    private suspend fun stopAppInternal(packageName: String, origin: StopOrigin): StopResult = withContext(Dispatchers.IO) {
        val result: StopResult = try {
            when {
                !PackageNameValidator.isValid(packageName) -> StopResult.PackageNotFound(packageName)
                !installedApps.isInstalled(packageName) -> StopResult.PackageNotFound(packageName)
                critical.isProtected(packageName) -> StopResult.ProtectedPackage(packageName)
                packageName in settings.settings.first().whitelist -> StopResult.ProtectedPackage(packageName)
                !shizuku.state.value.installed -> StopResult.ShizukuNotInstalled(packageName)
                !shizuku.state.value.binderAlive -> StopResult.ShizukuNotRunning(packageName)
                !shizuku.state.value.permissionGranted -> StopResult.PermissionDenied(packageName)
                else -> {
                    val service = shizuku.ensureService() ?: return@withContext record(StopResult.BinderDisconnected(packageName), packageName, origin)
                    val processes = runCatching { service.listProcesses() }.getOrDefault("")
                    if (!isRunning(processes, packageName)) StopResult.AlreadyStopped(packageName)
                    else {
                        val code = service.forceStop(packageName)
                        when (code) {
                            0 -> StopResult.Success(packageName)
                            13, 126 -> StopResult.ShellPermissionDenied(packageName)
                            64 -> StopResult.PackageNotFound(packageName)
                            else -> StopResult.CommandFailed(packageName, code)
                        }
                    }
                }
            }
        } catch (t: Throwable) {
            StopResult.UnknownError(packageName, t.message.orEmpty())
        }
        record(result, packageName, origin)
    }

    private suspend fun record(result: StopResult, packageName: String, origin: StopOrigin): StopResult {
        val s = shizuku.state.value
        val mode = when (s.privilegeUid) { 0 -> "ROOT/Sui"; 2000 -> "ADB/Shizuku"; else -> s.mode.name }
        history.add(
            StopHistory(
                timestamp = System.currentTimeMillis(),
                appLabel = installedApps.labelFor(packageName),
                packageName = packageName,
                success = result.isSuccessful(),
                reason = result.toTurkishMessage(),
                origin = origin,
                privilegeMode = mode
            )
        )
        return result
    }

    private fun isRunning(output: String, packageName: String): Boolean = output.lineSequence().any { line ->
        val name = line.trim().split(Regex("\\s+")).lastOrNull().orEmpty().substringBefore(':')
        name == packageName
    }
}
