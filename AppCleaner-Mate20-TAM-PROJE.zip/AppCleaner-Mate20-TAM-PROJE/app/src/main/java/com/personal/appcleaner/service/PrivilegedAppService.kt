package com.personal.appcleaner.service

import android.content.Context
import android.os.Process
import com.personal.appcleaner.shizuku.IPrivilegedAppService
import com.personal.appcleaner.util.PackageNameValidator
import java.io.BufferedReader
import java.io.InputStreamReader

class PrivilegedAppService() : IPrivilegedAppService.Stub() {
    @Suppress("UNUSED_PARAMETER")
    constructor(context: Context) : this()

    override fun forceStop(packageName: String): Int {
        if (!PackageNameValidator.isValid(packageName)) return 64
        return runCommand(listOf("/system/bin/am", "force-stop", packageName)).first
    }

    override fun listProcesses(): String {
        val preferred = runCommand(listOf("/system/bin/ps", "-A", "-o", "NAME"))
        if (preferred.first == 0 && preferred.second.isNotBlank()) return preferred.second
        return runCommand(listOf("/system/bin/ps", "-A")).second
    }

    override fun privilegeUid(): Int = Process.myUid()

    private fun runCommand(command: List<String>): Pair<Int, String> = try {
        val process = ProcessBuilder(command).redirectErrorStream(true).start()
        val output = BufferedReader(InputStreamReader(process.inputStream)).use { it.readText() }
        process.waitFor() to output.trim()
    } catch (t: Throwable) {
        127 to (t.message ?: t.javaClass.simpleName)
    }
}
