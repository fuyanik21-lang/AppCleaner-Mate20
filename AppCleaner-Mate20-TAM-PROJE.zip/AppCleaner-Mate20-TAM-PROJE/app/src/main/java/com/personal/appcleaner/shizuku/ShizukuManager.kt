package com.personal.appcleaner.shizuku

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Build
import android.os.IBinder
import com.personal.appcleaner.BuildConfig
import com.personal.appcleaner.model.ShizukuSetupMode
import com.personal.appcleaner.model.ShizukuState
import com.personal.appcleaner.service.PrivilegedAppService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withTimeoutOrNull
import rikka.shizuku.Shizuku

class ShizukuManager(private val context: Context) {
    private val _state = MutableStateFlow(ShizukuState())
    val state: StateFlow<ShizukuState> = _state.asStateFlow()

    private val _service = MutableStateFlow<IPrivilegedAppService?>(null)
    private var binding = false

    private val binderReceived = Shizuku.OnBinderReceivedListener { refresh() }
    private val binderDead = Shizuku.OnBinderDeadListener {
        _service.value = null
        binding = false
        refresh()
    }
    private val permissionResult = Shizuku.OnRequestPermissionResultListener { _, _ -> refresh() }

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            _service.value = binder?.takeIf { it.pingBinder() }?.let { IPrivilegedAppService.Stub.asInterface(it) }
            binding = false
            refresh()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            _service.value = null
            binding = false
            refresh()
        }
    }

    private val serviceArgs by lazy {
        Shizuku.UserServiceArgs(ComponentName(context.packageName, PrivilegedAppService::class.java.name))
            .daemon(false)
            .processNameSuffix("privileged")
            .debuggable(BuildConfig.DEBUG)
            .version(BuildConfig.VERSION_CODE)
    }

    init {
        runCatching { Shizuku.addBinderReceivedListener(binderReceived) }
        runCatching { Shizuku.addBinderDeadListener(binderDead) }
        runCatching { Shizuku.addRequestPermissionResultListener(permissionResult) }
        refresh()
    }

    fun refresh() {
        val installed = isInstalled()
        val binder = installed && runCatching { Shizuku.pingBinder() }.getOrDefault(false)
        val permission = binder && runCatching { Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED }.getOrDefault(false)
        val uid = if (binder) runCatching { Shizuku.getUid() }.getOrNull() else null
        val mode = when {
            uid == 0 -> ShizukuSetupMode.ROOT
            Build.VERSION.SDK_INT >= 30 -> ShizukuSetupMode.WIRELESS_DEBUGGING
            installed -> ShizukuSetupMode.COMPUTER_ADB
            else -> ShizukuSetupMode.UNAVAILABLE
        }
        _state.value = ShizukuState(
            installed = installed,
            binderAlive = binder,
            permissionGranted = permission,
            userServiceConnected = _service.value != null,
            privilegeUid = uid,
            mode = mode
        )
        if (binder && permission && _service.value == null) bindUserService()
    }

    fun requestPermission() {
        if (!state.value.binderAlive) return
        runCatching { Shizuku.requestPermission(REQUEST_CODE) }
            .onFailure { _state.value = _state.value.copy(error = it.message) }
    }

    fun bindUserService() {
        if (binding || _service.value != null) return
        val s = state.value
        if (!s.binderAlive || !s.permissionGranted) return
        binding = true
        runCatching { Shizuku.bindUserService(serviceArgs, serviceConnection) }
            .onFailure {
                binding = false
                _state.value = _state.value.copy(error = it.message)
            }
    }

    suspend fun ensureService(timeoutMs: Long = 6_000): IPrivilegedAppService? {
        _service.value?.let { return it }
        refresh()
        if (!state.value.binderAlive || !state.value.permissionGranted) return null
        bindUserService()
        return withTimeoutOrNull(timeoutMs) { _service.filterNotNull().first() }
    }

    fun isInstalled(): Boolean = try {
        if (Build.VERSION.SDK_INT >= 33) context.packageManager.getPackageInfo(SHIZUKU_PACKAGE, PackageManager.PackageInfoFlags.of(0))
        else @Suppress("DEPRECATION") context.packageManager.getPackageInfo(SHIZUKU_PACKAGE, 0)
        true
    } catch (_: Throwable) {
        false
    }

    companion object {
        const val SHIZUKU_PACKAGE = "moe.shizuku.privileged.api"
        private const val REQUEST_CODE = 4721
    }
}
