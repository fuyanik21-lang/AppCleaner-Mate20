package com.personal.appcleaner.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.personal.appcleaner.MainViewModel
import com.personal.appcleaner.ui.screens.CleanScreen
import com.personal.appcleaner.ui.screens.ExcludedScreen
import com.personal.appcleaner.ui.screens.HistoryScreen
import com.personal.appcleaner.ui.screens.SettingsScreen

private data class Tab(val route: String, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

@Composable
fun AppCleanerApp(vm: MainViewModel) {
    val state by vm.ui.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val history by vm.history.collectAsStateWithLifecycle()
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val tabs = listOf(
        Tab("clean", "Temizle", Icons.Default.CleaningServices),
        Tab("excluded", "Hariç", Icons.Default.Security),
        Tab("history", "Geçmiş", Icons.Default.History),
        Tab("settings", "Ayarlar", Icons.Default.Settings)
    )

    Scaffold(bottomBar = {
        NavigationBar {
            tabs.forEach { tab ->
                NavigationBarItem(
                    selected = backStack?.destination?.route == tab.route,
                    onClick = { nav.navigate(tab.route) { launchSingleTop = true; restoreState = true; popUpTo("clean") { saveState = true } } },
                    icon = { Icon(tab.icon, tab.label) },
                    label = { Text(tab.label) }
                )
            }
        }
    }) { padding ->
        Box(Modifier.padding(padding)) {
            NavHost(navController = nav, startDestination = "clean") {
                composable("clean") { CleanScreen(state, vm) }
                composable("excluded") { ExcludedScreen(state, vm) }
                composable("history") { HistoryScreen(history, vm) }
                composable("settings") { SettingsScreen(state, settings, vm) }
            }
        }
    }

    state.message?.let { message ->
        AlertDialog(
            onDismissRequest = vm::clearMessage,
            text = { Text(message) },
            confirmButton = { TextButton(onClick = vm::clearMessage) { Text("Tamam") } }
        )
    }
}
