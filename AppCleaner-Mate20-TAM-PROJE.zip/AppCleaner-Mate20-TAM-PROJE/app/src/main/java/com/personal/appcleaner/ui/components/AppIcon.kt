package com.personal.appcleaner.ui.components

import android.graphics.Bitmap
import android.os.Build
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private object IconCache {
    val cache = LruCache<String, Bitmap>(64)
}

@Composable
fun AppIcon(packageName: String, label: String, modifier: Modifier = Modifier.size(42.dp)) {
    val context = LocalContext.current
    val bitmap = produceState<Bitmap?>(initialValue = IconCache.cache.get(packageName), packageName) {
        if (value == null) {
            value = withContext(Dispatchers.IO) {
                runCatching {
                    val pm = context.packageManager
                    val info = if (Build.VERSION.SDK_INT >= 33) pm.getApplicationInfo(packageName, android.content.pm.PackageManager.ApplicationInfoFlags.of(0))
                    else @Suppress("DEPRECATION") pm.getApplicationInfo(packageName, 0)
                    pm.getApplicationIcon(info).toBitmap(96, 96).also { IconCache.cache.put(packageName, it) }
                }.getOrNull()
            }
        }
    }.value
    if (bitmap != null) Image(bitmap.asImageBitmap(), contentDescription = label, modifier = modifier)
    else Icon(Icons.Default.Android, contentDescription = label, modifier = modifier)
}
