package com.personal.appcleaner.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.personal.appcleaner.MainViewModel
import com.personal.appcleaner.model.AppFilter
import com.personal.appcleaner.model.AppInfo
import com.personal.appcleaner.model.AppPresence
import com.personal.appcleaner.model.AppUiState
import com.personal.appcleaner.ui.components.AppIcon

@Composable
fun CleanScreen(state: AppUiState, vm: MainViewModel) {
    val apps = vm.visibleApps(state)
    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatusCard("Shizuku", if (state.shizuku.ready) "✓ Aktif" else "✗ Aktif değil", Modifier.weight(1f))
            StatusCard("Usage Access", if (state.usageAccess) "✓ İzinli" else "✗ İzin gerekli", Modifier.weight(1f))
        }
        Spacer(Modifier.height(8.dp))
        Text("Çalışan/yakın: ${state.apps.count { it.presence != AppPresence.UNKNOWN }}   •   Seçili: ${state.selectedCount}")
        if (!state.shizuku.installed) {
            Card(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                Column(Modifier.padding(12.dp)) {
                    Text("Uygulamaları doğrudan durdurabilmek için Shizuku gerekiyor.")
                    Button(onClick = vm::openShizukuInstall, modifier = Modifier.padding(top = 8.dp)) { Text("SHIZUKU'YU KUR") }
                }
            }
        } else if (!state.shizuku.binderAlive) {
            Card(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                Column(Modifier.padding(12.dp)) {
                    Text("Shizuku kurulu ancak çalışmıyor.")
                    Text(if (android.os.Build.VERSION.SDK_INT <= 29) "Huawei Mate 20 / Android 10 için bilgisayar üzerinden ADB ile Shizuku'yu başlatın." else "Shizuku uygulamasından servisi başlatın.")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = vm::openShizuku) { Text("SHIZUKU'YU AÇ") }
                        OutlinedButton(onClick = vm::openDeveloperOptions) { Text("ADB AYARLARI") }
                    }
                }
            }
        } else if (!state.shizuku.permissionGranted) {
            Button(onClick = vm::requestShizukuPermission, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) { Text("SHIZUKU İZNİ VER") }
        }
        if (!state.usageAccess) {
            OutlinedButton(onClick = vm::openUsageAccess, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) { Text("KULLANIM ERİŞİMİ İZNİ VER") }
        }

        OutlinedTextField(
            value = state.query,
            onValueChange = vm::setQuery,
            label = { Text("Uygulama veya paket ara") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
            trailingIcon = { IconButton(onClick = vm::refresh) { Icon(Icons.Default.Refresh, "Yenile") } }
        )
        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            AppFilter.entries.forEach { filter ->
                FilterChip(selected = state.filter == filter, onClick = { vm.setFilter(filter) }, label = { Text(filter.title) })
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedButton(onClick = vm::selectAllVisible, modifier = Modifier.weight(1f)) { Text("Tümünü seç") }
            OutlinedButton(onClick = vm::clearSelection, modifier = Modifier.weight(1f)) { Text("Temizle") }
        }
        Button(onClick = vm::requestBatchConfirmation, enabled = state.selectedCount > 0 && state.shizuku.ready, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
            Text("SEÇİLENLERİ DURDUR")
        }
        if (state.loading) CircularProgressIndicator(Modifier.align(Alignment.CenterHorizontally))
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(apps, key = { it.packageName }) { app -> AppRow(app, state.shizuku.ready, vm) }
        }
    }

    if (state.confirmBatch) {
        AlertDialog(
            onDismissRequest = vm::cancelBatch,
            title = { Text("Toplu durdurma") },
            text = { Text("${state.selectedCount} uygulama durdurulacak. Devam edilsin mi?") },
            confirmButton = { TextButton(onClick = vm::stopSelected) { Text("DURDUR") } },
            dismissButton = { TextButton(onClick = vm::cancelBatch) { Text("İPTAL") } }
        )
    }
}

@Composable
private fun StatusCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) { Column(Modifier.padding(10.dp)) { Text(title, style = MaterialTheme.typography.labelMedium); Text(value) } }
}

@Composable
private fun AppRow(app: AppInfo, shizukuReady: Boolean, vm: MainViewModel) {
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Checkbox(checked = app.selected, onCheckedChange = { vm.toggleSelected(app.packageName) }, enabled = !app.isProtected && !app.isWhitelisted)
            AppIcon(app.packageName, app.label)
            Column(Modifier.weight(1f)) {
                Text(app.label, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(app.packageName, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    buildString {
                        append(if (app.isSystem) "Sistem" else "Kullanıcı")
                        append(" • ")
                        append(when (app.presence) { AppPresence.RUNNING -> "Çalışıyor"; AppPresence.RECENT -> "Yakın zamanda kullanıldı"; AppPresence.UNKNOWN -> "Pasif" })
                        if (app.isProtected) append(" • Korumalı")
                    }, style = MaterialTheme.typography.labelSmall
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                TextButton(onClick = { vm.stopOne(app.packageName) }, enabled = shizukuReady && !app.isProtected && !app.isWhitelisted) { Text("Durdur") }
                AssistChip(onClick = { vm.setWhitelisted(app.packageName, !app.isWhitelisted) }, label = { Text(if (app.isWhitelisted) "Korumayı kaldır" else "Asla kapatma") })
            }
        }
    }
}
