package com.personal.appcleaner.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.personal.appcleaner.MainViewModel
import com.personal.appcleaner.model.AppUiState

@Composable
fun ExcludedScreen(state: AppUiState, vm: MainViewModel) {
    val items = state.apps.filter { it.isWhitelisted }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("Hariç Tutulanlar", style = MaterialTheme.typography.headlineSmall)
        LazyColumn {
            items(items, key = { it.packageName }) { app ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text(app.label)
                        Text(app.packageName, style = MaterialTheme.typography.bodySmall)
                        TextButton(onClick = { vm.setWhitelisted(app.packageName, false) }) { Text("Listeden çıkar") }
                    }
                }
            }
        }
    }
}
