package com.personal.appcleaner.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.personal.appcleaner.MainViewModel
import com.personal.appcleaner.model.StopHistory
import java.text.DateFormat
import java.util.Date

@Composable
fun HistoryScreen(history: List<StopHistory>, vm: MainViewModel) {
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("İşlem Geçmişi", style = MaterialTheme.typography.headlineSmall)
        OutlinedButton(onClick = vm::clearHistory, modifier = Modifier.padding(vertical = 8.dp)) { Text("GEÇMİŞİ TEMİZLE") }
        LazyColumn {
            items(history, key = { "${it.timestamp}:${it.packageName}" }) { item ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(Modifier.padding(10.dp)) {
                        Text("${if (item.success) "✓" else "✗"} ${item.appLabel}")
                        Text(item.packageName, style = MaterialTheme.typography.bodySmall)
                        Text(DateFormat.getDateTimeInstance().format(Date(item.timestamp)), style = MaterialTheme.typography.labelSmall)
                        Text("${if (item.origin.name == "MANUAL") "Manuel" else "Otomatik"} • ${item.privilegeMode}", style = MaterialTheme.typography.labelSmall)
                        Text(item.reason, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}
