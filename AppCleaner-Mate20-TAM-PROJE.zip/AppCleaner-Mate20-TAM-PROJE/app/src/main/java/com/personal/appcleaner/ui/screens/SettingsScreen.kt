package com.personal.appcleaner.ui.screens

import android.os.Build
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.personal.appcleaner.MainViewModel
import com.personal.appcleaner.model.AppUiState
import com.personal.appcleaner.model.AutoCleanInterval
import com.personal.appcleaner.model.CleanerSettings

@Composable
fun SettingsScreen(state: AppUiState, settings: CleanerSettings, vm: MainViewModel) {
    LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text("Ayarlar", style = MaterialTheme.typography.headlineSmall) }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Shizuku", style = MaterialTheme.typography.titleMedium)
                    Text("Kurulu: ${if (state.shizuku.installed) "Evet" else "Hayır"}")
                    Text("Servis: ${if (state.shizuku.binderAlive) "Aktif" else "Kapalı"}")
                    Text("İzin: ${if (state.shizuku.permissionGranted) "Verildi" else "Gerekli"}")
                    Text("Mod: ${state.shizuku.mode}")
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (!state.shizuku.installed) Button(onClick = vm::openShizukuInstall) { Text("Shizuku kur") }
                        else OutlinedButton(onClick = vm::openShizuku) { Text("Shizuku'yu aç") }
                        if (state.shizuku.binderAlive && !state.shizuku.permissionGranted) Button(onClick = vm::requestShizukuPermission) { Text("İzin ver") }
                    }
                    if (Build.VERSION.SDK_INT <= 29) {
                        Text("Mate 20 / Android 10: Shizuku rootsuz kullanımda bilgisayar ADB ile başlatılır. Telefon yeniden açılırsa bu işlem tekrarlanabilir.")
                        OutlinedButton(onClick = vm::openDeveloperOptions) { Text("Geliştirici seçenekleri") }
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text("Usage Access", style = MaterialTheme.typography.titleMedium)
                    Text(if (state.usageAccess) "İzinli" else "İzin gerekli")
                    OutlinedButton(onClick = vm::openUsageAccess) { Text("Kullanım erişimi ayarları") }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text("Otomatik temizleme", style = MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        AutoCleanInterval.entries.forEach { interval ->
                            FilterChip(selected = settings.autoCleanInterval == interval, onClick = { vm.setAutoInterval(interval) }, label = { Text(interval.title) })
                        }
                    }
                    Text("EMUI, WorkManager görevlerini geciktirebilir; zamanlama kesin değildir.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text("Son kullanılanları koru", style = MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        listOf(0, 5, 15, 30, 60).forEach { minutes ->
                            FilterChip(selected = settings.protectRecentMinutes == minutes, onClick = { vm.setRecentProtection(minutes) }, label = { Text(if (minutes == 0) "Kapalı" else "$minutes dk") })
                        }
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text("Huawei Arka Plan Ayarları", style = MaterialTheme.typography.titleMedium)
                    Text("Ayarlar → Pil → Uygulama başlatma → App Cleaner → Otomatik yönetimi kapat. Varsa Otomatik başlatma, İkincil başlatma ve Arka planda çalıştırma seçeneklerini açın.", style = MaterialTheme.typography.bodySmall)
                    OutlinedButton(onClick = vm::openHuaweiSettings) { Text("Huawei pil ayarlarını aç") }
                }
            }
        }
        item { Text("Otomatik temizlenecek uygulamalar", style = MaterialTheme.typography.titleMedium) }
        items(state.apps.filter { !it.isSystem && !it.isProtected }, key = { "auto:${it.packageName}" }) { app ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = app.isAutoClean, onCheckedChange = { vm.setAutoCleanPackage(app.packageName, it) })
                Column(Modifier.weight(1f)) { Text(app.label); Text(app.packageName, style = MaterialTheme.typography.labelSmall) }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text("Hakkında", style = MaterialTheme.typography.titleMedium)
                    Text("App Cleaner kişisel kullanım için hazırlanmıştır. İnternet, reklam, analytics ve telemetry kullanmaz. Force-stop yalnızca Shizuku/Sui/root yetkisi mevcutken yapılır.")
                }
            }
        }
    }
}
