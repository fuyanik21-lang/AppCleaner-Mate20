package com.personal.appcleaner.util

import android.accessibilityservice.AccessibilityService
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.provider.Settings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class CriticalAppDetector(private val context: Context) {
    private val pm get() = context.packageManager

    suspend fun protectedPackages(): Set<String> = withContext(Dispatchers.IO) {
        buildSet {
            addAll(hardBlocked(context.packageName))
            addAll(knownCritical)

            runCatching {
                val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                pm.resolveActivity(home, 0)?.activityInfo?.packageName?.let { add(it) }
            }
            runCatching {
                pm.resolveActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:")), 0)?.activityInfo?.packageName?.let { add(it) }
            }
            runCatching {
                val ime = Settings.Secure.getString(context.contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
                ComponentName.unflattenFromString(ime.orEmpty())?.packageName?.let { add(it) }
            }
            runCatching {
                queryServicePackages(Intent(AccessibilityService.SERVICE_INTERFACE)).forEach { add(it) }
            }
            runCatching {
                queryServicePackages(Intent(VpnService.SERVICE_INTERFACE)).forEach { add(it) }
            }
            runCatching {
                context.getSystemService(DevicePolicyManager::class.java).activeAdmins?.forEach { add(it.packageName) }
            }
        }
    }

    suspend fun isProtected(packageName: String): Boolean = packageName in protectedPackages()

    private fun queryServicePackages(intent: Intent): Set<String> {
        val services = if (Build.VERSION.SDK_INT >= 33) {
            pm.queryIntentServices(intent, android.content.pm.PackageManager.ResolveInfoFlags.of(android.content.pm.PackageManager.GET_META_DATA.toLong()))
        } else {
            @Suppress("DEPRECATION") pm.queryIntentServices(intent, android.content.pm.PackageManager.GET_META_DATA)
        }
        return services.mapNotNull { it.serviceInfo?.packageName }.toSet()
    }

    companion object {
        private val knownCritical = setOf(
            "com.android.settings", "com.android.phone", "com.android.server.telecom",
            "com.android.packageinstaller", "com.google.android.packageinstaller",
            "com.huawei.android.launcher", "com.huawei.systemmanager", "com.huawei.hwid",
            "com.huawei.android.pushagent", "com.huawei.android.internal.app",
            "com.huawei.contacts", "com.huawei.android.totemweather"
        )

        fun hardBlocked(selfPackage: String): Set<String> = setOf(
            selfPackage,
            "moe.shizuku.privileged.api",
            "android",
            "com.android.systemui"
        )

        fun isHardBlocked(packageName: String, selfPackage: String): Boolean = packageName in hardBlocked(selfPackage)
    }
}
