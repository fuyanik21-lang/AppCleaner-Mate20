package com.personal.appcleaner.util

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings

class HuaweiDeviceHelper(private val context: Context) {
    fun isHuaweiDevice(): Boolean = isHuawei(Build.MANUFACTURER, Build.BRAND)

    fun openBackgroundSettings() {
        val candidates = listOf(
            Intent().setComponent(ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity")),
            Intent().setComponent(ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity")),
            Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS),
            Intent(Settings.ACTION_SETTINGS)
        )
        candidates.forEach { intent ->
            try {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                return
            } catch (_: Throwable) { }
        }
    }

    companion object {
        fun isHuawei(manufacturer: String?, brand: String?): Boolean =
            manufacturer.equals("HUAWEI", true) || brand.equals("HUAWEI", true) || brand.equals("HONOR", true)
    }
}
