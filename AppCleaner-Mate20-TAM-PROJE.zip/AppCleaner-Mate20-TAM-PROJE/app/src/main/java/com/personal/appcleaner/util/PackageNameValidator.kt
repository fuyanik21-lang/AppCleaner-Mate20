package com.personal.appcleaner.util

object PackageNameValidator {
    private val pattern = Regex("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+$")
    fun isValid(packageName: String): Boolean = packageName.length in 3..255 && pattern.matches(packageName)
}

object WhitelistPolicy {
    fun canStop(packageName: String, whitelist: Set<String>): Boolean = packageName !in whitelist
}
