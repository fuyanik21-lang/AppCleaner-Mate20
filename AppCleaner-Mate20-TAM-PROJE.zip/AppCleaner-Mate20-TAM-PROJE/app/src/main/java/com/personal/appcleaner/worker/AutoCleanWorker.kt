package com.personal.appcleaner.worker

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.personal.appcleaner.AppCleanerApplication
import com.personal.appcleaner.model.AutoCleanInterval
import com.personal.appcleaner.repository.RecentUsagePolicy
import kotlinx.coroutines.flow.first
import java.util.concurrent.TimeUnit

class AutoCleanWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        val app = applicationContext as AppCleanerApplication
        val c = app.container
        val cfg = c.settingsRepository.settings.first()
        if (cfg.autoCleanPackages.isEmpty()) return Result.success()
        c.shizukuManager.refresh()
        if (!c.shizukuManager.state.value.binderAlive || !c.shizukuManager.state.value.permissionGranted) return Result.success()

        val foreground = c.usageStatsRepository.foregroundPackage()
        val now = System.currentTimeMillis()
        for (pkg in cfg.autoCleanPackages) {
            if (pkg == foreground) continue
            if (cfg.protectRecentMinutes > 0) {
                if (!c.usageStatsRepository.hasUsageAccess()) continue
                val last = c.usageStatsRepository.lastUsed(pkg)
                if (RecentUsagePolicy.shouldProtect(last, now, cfg.protectRecentMinutes)) continue
            }
            c.appStopManager.stopAppAutomatic(pkg)
        }
        return Result.success()
    }
}

object AutoCleanScheduler {
    private const val UNIQUE = "app_cleaner_periodic"

    fun apply(context: Context, interval: AutoCleanInterval) {
        val wm = WorkManager.getInstance(context)
        if (interval == AutoCleanInterval.OFF) {
            wm.cancelUniqueWork(UNIQUE)
            return
        }
        val request = PeriodicWorkRequestBuilder<AutoCleanWorker>(interval.minutes, TimeUnit.MINUTES).build()
        wm.enqueueUniquePeriodicWork(UNIQUE, ExistingPeriodicWorkPolicy.UPDATE, request)
    }
}
