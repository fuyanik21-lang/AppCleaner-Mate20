package com.personal.appcleaner

import com.personal.appcleaner.model.BatchSummary
import com.personal.appcleaner.model.StopResult
import org.junit.Assert.assertEquals
import org.junit.Test

class BatchStopTest {
    @Test fun batchSummaryCountsResults() {
        val result = BatchSummary.from(listOf(StopResult.Success("a.b"), StopResult.AlreadyStopped("c.d"), StopResult.PermissionDenied("e.f")))
        assertEquals(3, result.total)
        assertEquals(2, result.successful)
        assertEquals(1, result.failed)
    }
}
