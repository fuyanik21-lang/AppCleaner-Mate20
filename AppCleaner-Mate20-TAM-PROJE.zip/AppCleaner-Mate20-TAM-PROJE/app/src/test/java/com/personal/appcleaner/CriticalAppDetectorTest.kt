package com.personal.appcleaner

import com.personal.appcleaner.util.CriticalAppDetector
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CriticalAppDetectorTest {
    @Test fun hardCriticalPackagesAreBlocked() {
        assertTrue(CriticalAppDetector.isHardBlocked("android", "com.personal.appcleaner"))
        assertTrue(CriticalAppDetector.isHardBlocked("com.android.systemui", "com.personal.appcleaner"))
        assertTrue(CriticalAppDetector.isHardBlocked("com.personal.appcleaner", "com.personal.appcleaner"))
        assertFalse(CriticalAppDetector.isHardBlocked("com.example.normal", "com.personal.appcleaner"))
    }
}
