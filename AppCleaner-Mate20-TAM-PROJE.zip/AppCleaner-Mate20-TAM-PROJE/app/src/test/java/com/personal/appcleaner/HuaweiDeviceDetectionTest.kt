package com.personal.appcleaner

import com.personal.appcleaner.util.HuaweiDeviceHelper
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class HuaweiDeviceDetectionTest {
    @Test fun detectsHuawei() {
        assertTrue(HuaweiDeviceHelper.isHuawei("HUAWEI", "HUAWEI"))
        assertTrue(HuaweiDeviceHelper.isHuawei("unknown", "HONOR"))
        assertFalse(HuaweiDeviceHelper.isHuawei("Google", "Pixel"))
    }
}
