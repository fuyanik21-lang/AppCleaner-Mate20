package com.personal.appcleaner

import com.personal.appcleaner.util.PackageNameValidator
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PackageNameValidatorTest {
    @Test fun acceptsAndroidPackage() = assertTrue(PackageNameValidator.isValid("com.example.app"))
    @Test fun rejectsShellInjection() {
        assertFalse(PackageNameValidator.isValid("com.example.app;reboot"))
        assertFalse(PackageNameValidator.isValid("com.example.app && id"))
        assertFalse(PackageNameValidator.isValid("com.example.app\nreboot"))
    }
}
