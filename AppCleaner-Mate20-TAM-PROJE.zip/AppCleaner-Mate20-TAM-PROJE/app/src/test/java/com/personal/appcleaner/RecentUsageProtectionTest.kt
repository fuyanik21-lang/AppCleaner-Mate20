package com.personal.appcleaner

import com.personal.appcleaner.repository.RecentUsagePolicy
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RecentUsageProtectionTest {
    @Test fun recentUsageIsProtected() {
        val now = 1_000_000L
        assertTrue(RecentUsagePolicy.shouldProtect(now - 4 * 60_000, now, 5))
        assertFalse(RecentUsagePolicy.shouldProtect(now - 6 * 60_000, now, 5))
    }
}
