package com.personal.appcleaner

import com.personal.appcleaner.data.DependencyManager
import com.personal.appcleaner.model.ShizukuSetupMode
import org.junit.Assert.assertEquals
import org.junit.Test

class ShizukuUnavailableFallbackTest {
    @Test fun android10UsesComputerAdb() = assertEquals(ShizukuSetupMode.COMPUTER_ADB, DependencyManager.resolveMode(29, false, true))
    @Test fun missingShizukuIsUnavailable() = assertEquals(ShizukuSetupMode.UNAVAILABLE, DependencyManager.resolveMode(29, false, false))
}
