package com.personal.appcleaner

import com.personal.appcleaner.model.StopResult
import com.personal.appcleaner.model.isSuccessful
import com.personal.appcleaner.model.toTurkishMessage
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class StopResultTest {
    @Test fun successClassificationWorks() {
        assertTrue(StopResult.Success("com.x.app").isSuccessful())
        assertTrue(StopResult.AlreadyStopped("com.x.app").isSuccessful())
        assertFalse(StopResult.PermissionDenied("com.x.app").isSuccessful())
    }
    @Test fun messagesAreTurkish() = assertTrue(StopResult.PermissionDenied("com.x.app").toTurkishMessage().contains("izin", true))
}
