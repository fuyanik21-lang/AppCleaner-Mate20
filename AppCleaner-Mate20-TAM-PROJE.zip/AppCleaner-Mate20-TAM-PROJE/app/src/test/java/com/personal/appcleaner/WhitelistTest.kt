package com.personal.appcleaner

import com.personal.appcleaner.util.WhitelistPolicy
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WhitelistTest {
    @Test fun whitelistBlocksStop() {
        assertFalse(WhitelistPolicy.canStop("com.example.safe", setOf("com.example.safe")))
        assertTrue(WhitelistPolicy.canStop("com.example.other", setOf("com.example.safe")))
    }
}
